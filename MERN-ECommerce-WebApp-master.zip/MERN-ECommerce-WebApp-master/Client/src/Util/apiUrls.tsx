export const userURL = "/api/users";

export const loginUrl = "/api/login";
export const registerUrl = "/api/register";

export const cartUrlBase = "/api/cart/";
export const orderUrlBase = "/api/orders/";
export const wishlistUrlBase = "/api/wishlist/";