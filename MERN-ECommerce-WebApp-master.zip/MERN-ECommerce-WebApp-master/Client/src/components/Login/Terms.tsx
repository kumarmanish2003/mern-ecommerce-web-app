import { MDBContainer, MDBTypography } from "mdb-react-ui-kit";

function Terms() {
  return (
    <MDBContainer>
      <MDBTypography className="text-center m-10" tag="h1">
        No Terms LOL
      </MDBTypography>
    </MDBContainer>
  )
}

export default Terms;
